package com.xheki.skinstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkinstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
