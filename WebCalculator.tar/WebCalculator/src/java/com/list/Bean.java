/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.list;

import java.util.ArrayList;

/**
 *
 * @author MuhamedKura
 */

public class Bean {
    
    private int FirstNumber = 0;
    private int SecondNumber = 0;
    private String Operation = "ADD";
    private double Result = 0;
    private static ArrayList history;
    private static int index = 0;
    
    public Bean(){
        getInitHistory();
        System.out.println(" test "+history);
    }
 
    public double getResult() {
        // Check the caracters if they are numbers or not
        if (Operation.equalsIgnoreCase("ADD")) {
            Result = FirstNumber + SecondNumber;
            return Result;
        } else if (Operation.trim().equalsIgnoreCase("SUBTRACT")) {
            Result = FirstNumber - SecondNumber;
            return Result; 
        } else if(Operation.equalsIgnoreCase ("MULTIPLY")) {
            Result = FirstNumber * SecondNumber;
            return Result;
        } else if(Operation.equalsIgnoreCase("DIVIDE"))    {
            Result = FirstNumber / SecondNumber;
            return Result;
        } 
        return 0;
   }

    private void getInitHistory(){
        setHistory(new ArrayList());
        getHistory().add("history of opertions ");
        getHistory().add(FirstNumber +" "+Operation+" "+ SecondNumber + " = "+Result);
    }

    public void setFirstNumber(int FirstNumber){
        
        System.err.println(FirstNumber);
        this.FirstNumber = FirstNumber;
    }
    public void setSecondNumber(int SecondNumber){
        this.SecondNumber = SecondNumber;
    }
    public void setOperation(String Operation){
        this.Operation = Operation;
    }
   
    public int getFirstNumber(){
       // System.out.println("First is "+FirstNumber);
         return FirstNumber;
    }
    public int getSecondNumber(){
         return SecondNumber;
    }
    public String getOperation(){
        return Operation;
    } 

    /**
     * @return the history
     */
    public static ArrayList getHistory() {
        return history;
    }

    /**
     * @param aHistory the history to set
     */
    public static void setHistory(ArrayList aHistory) {
        history = aHistory;
    }
        

}

